import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TechnologyComponent } from './technology/technology.component';
import { InsertTechnologiesComponent } from './insert-technologies/insert-technologies.component';
import { MentorsComponent } from './mentors/mentors.component';


const routes: Routes = [

  {
    path:'technologylist',component: TechnologyComponent},
   { path:'inserttech',component: InsertTechnologiesComponent
  },
  {
    path:'mentorlist',component: MentorsComponent
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
