import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InsertTechnologiesComponent } from './insert-technologies.component';

describe('InsertTechnologiesComponent', () => {
  let component: InsertTechnologiesComponent;
  let fixture: ComponentFixture<InsertTechnologiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InsertTechnologiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InsertTechnologiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
