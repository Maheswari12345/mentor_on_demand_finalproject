import { Component, OnInit } from '@angular/core';
import { Technologies } from '../technology/technology';
import { HttpclientService } from '../service/httpclient.service';

@Component({
  selector: 'app-insert-technologies',
  templateUrl: './insert-technologies.component.html',
  styleUrls: ['./insert-technologies.component.css']
})
export class InsertTechnologiesComponent implements OnInit {
  technologies: Technologies=new Technologies(0,"","","","");
  constructor(
    private httpClientService: HttpclientService
  ) { }

  ngOnInit() {
  }
  inserttechnologies(): void{
    this.httpClientService.inserttechnologies(this.technologies).subscribe(data => 
      {
        alert("Technologies added successfully");
      });
  };

}
