export class Mentor
{
    constructor(
       id:number,
       linkedinUrl:string,
       regCode:string,
       userName:string,
       yearsOfExperience:string,
       course:string,
    )
    {}

}