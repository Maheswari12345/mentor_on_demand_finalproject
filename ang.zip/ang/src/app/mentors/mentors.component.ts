import { Component, OnInit } from '@angular/core';
import { HttpclientService } from '../service/httpclient.service';
import { Mentor } from './mentor';

@Component({
  selector: 'app-mentors',
  templateUrl: './mentors.component.html',
  styleUrls: ['./mentors.component.css']
})
export class MentorsComponent implements OnInit {

  mentor:Mentor[];
  constructor(
    private httpClientService:HttpclientService
  ) { }

  
  ngOnInit() {
    this.httpClientService.getMentors().subscribe(
      response =>this.mentor=response
    );
    console.log(this.mentor);
  }
  handleSuccessfulResponse(response){
    this.mentor=response;
  }
}
