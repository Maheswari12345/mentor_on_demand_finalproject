import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { logging } from 'protractor';


@Injectable({
  providedIn: 'root'
})
export class HttpclientService {

  constructor(
    private httpClient:HttpClient
  ) { 

  }


getTechnologies()
{
console.log("test call");
return this.httpClient.get<any>('http://localhost:9090/api/techlist');
}
getMentors()
{
  console.log("test call");
  return this.httpClient.get<any>('http://localhost:9090/api/mentorlist');
}
public inserttechnologies(technologies)

{
  return this.httpClient.post<any>("http://localhost:9090/api/inserttech", technologies);
}
deletetechnologies(technologies)
{
  return this.httpClient.delete<any>("http://localhost:9090/api/tech"+ "/"+technologies.id);
}

}