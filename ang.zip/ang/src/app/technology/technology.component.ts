import { Component, OnInit } from '@angular/core';
import { HttpclientService } from '../service/httpclient.service';
import { Technologies } from './technology';
import { Router } from '@angular/router';

@Component({
  selector: 'app-technology',
  templateUrl: './technology.component.html',
  styleUrls: ['./technology.component.css']
})
export class TechnologyComponent implements OnInit {
 technologies:Technologies[];
  constructor(
    private httpClientService:HttpclientService,
    private router: Router
  ) { }
 
  ngOnInit() {
    this.httpClientService.getTechnologies().subscribe(
      response =>this.technologies=response
    );
    console.log(this.technologies);
  }
  handleSuccessfulResponse(response){
    this.technologies=response;
  }
  deletetechnologies(technologies: Technologies): void {
    this.httpClientService.deletetechnologies(technologies)
      .subscribe( data => {
        this.technologies = this.technologies.filter(u => u !== technologies);
        this.router.navigate(['technologylist'])
      })
  };



}
