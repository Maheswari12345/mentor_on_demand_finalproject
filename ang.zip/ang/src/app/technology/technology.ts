export class Technologies {

constructor(
	 id:number,
    

	 name:string,
	 
	
	toc:string,
	
   
	 duration:string,
	 preRequites:string,

)
{}

}
