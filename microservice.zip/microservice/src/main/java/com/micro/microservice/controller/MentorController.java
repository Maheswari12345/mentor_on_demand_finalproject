package com.micro.microservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.micro.microservice.model.Mentor;
import com.micro.microservice.service.MentorService;

@Controller
public class MentorController {
	@Autowired
	MentorService mservice;

	
	
	@GetMapping(value="/mentorlist")
	public List<Mentor> findall() throws Exception
	{
		return mservice.getmentorslist();
	}
	 
	@GetMapping(value="/studentslist")
	public List<Mentor> findstudentlist() throws Exception
	{
		return mservice.getmentorslist();
	}
}