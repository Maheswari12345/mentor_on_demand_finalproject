package com.micro.microservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.micro.microservice.model.Mentor;

public interface Mentordao extends JpaRepository<Mentor,Integer> {

}
