package com.micro.microservice.service;

import java.util.List;

import com.micro.microservice.model.Mentor;

public interface MentorService {
	public Mentor insertmentors(Mentor mentor);
	List<Mentor> getmentorslist() throws Exception;
	public void deletementor(Integer id);
	

}