package com.mentorondemand.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mentorondemand.dao.MentorRepository;
import com.mentorondemand.dao.MentorSkillRepository;
import com.mentorondemand.model.Mentor;
import com.mentorondemand.model.MentorCalendar;
import com.mentorondemand.model.MentorSkills;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class MentorController {
	@Autowired
	   MentorRepository mentorRepo;
	
	@Autowired
	   MentorSkillRepository skillRepo;
	

	
	@PostMapping("/mentorregister")
	public Mentor mentorregister(Mentor mentor)
	{
		return mentorRepo.save(mentor);
	}
	@GetMapping("/mentorlist")
	public List<Mentor> getmentors()
	{
		return (List<Mentor>) mentorRepo.findAll();
	}
	
}
