package com.mentorondemand.controller;



import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mentorondemand.dao.TechnologiesRepository;
import com.mentorondemand.dao.TrainingRepository;
import com.mentorondemand.model.Courses;
import com.mentorondemand.model.Trainings;





@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class TrainingController {

	@Autowired
   TrainingRepository trainingRepo;
	@Autowired
	TechnologiesRepository techrepo;
	
	@PostMapping("/inserttech")
	public Courses inserttechnologies(@RequestBody Courses t)
	{
		return techrepo.save(t);
	}

	@GetMapping("/getTrainingDetails/{id}")
	public Optional<Trainings> getAllCustomers(@PathVariable long id) {
		System.out.println("Get all trainings details...");

		
		Optional<Trainings> trainings=trainingRepo.findById(id);

		return trainings;
	}
	@GetMapping(value = "getCompletedTrainings/{status}")
	public List<Trainings> findByStatus(@PathVariable String status) {

		List<Trainings> trainings= trainingRepo.findByStatus(status);
		return trainings;
	}
	
	@GetMapping(value = "getUnderProgressTrainings/{userId}")
	public List<Trainings> findByProgress(@PathVariable long userId) {

		List<Trainings> trainings= trainingRepo.findByUserId(userId);
		List<Trainings> trainingList= new ArrayList();
		Iterator itr = trainings.iterator(); 
		while(itr.hasNext()) {
			Trainings training=(Trainings)itr.next();
			if(training.getStatus().equals("inprogress")) {
				trainingList.add(training);
			}
			
		}
		return trainingList;
	}
	@GetMapping(value = "proposedTrainings/{userId}")
	public List<Trainings> findByProposal(@PathVariable long userId) {

		List<Trainings> trainings= trainingRepo.findByUserId(userId);
		List<Trainings> trainingList= new ArrayList();
		Iterator itr = trainings.iterator(); 
		while(itr.hasNext()) {
			Trainings training=(Trainings)itr.next();
			if(training.getStatus().equals("proposed")) {
				training.setStatus("approved");
				trainingList.add(training);
			}
			
		}
		return trainingList;
	}
	@GetMapping(value = "finalizeTraining/amount/{amountReceived}")
	public List<Trainings> findByPayment(@PathVariable String amountReceived) {
       List<Trainings> trainings= trainingRepo.findByAmountReceived(amountReceived);
		return trainings;
	}
   @GetMapping(value="/traininglist")
   public List<Trainings> findall()
   {
	   return trainingRepo.findAll();
   }
   @GetMapping(value="/techlist")
   public List<Courses> listalltech()
   {
	   return (List<Courses>) techrepo.findAll();
   }
   @DeleteMapping(value="/tech/{id}")
   public String deletecourses(@PathVariable long id)
   {
	   techrepo.deleteById(id);
	return "redirect:/techlist";
	   
   }
   
}
