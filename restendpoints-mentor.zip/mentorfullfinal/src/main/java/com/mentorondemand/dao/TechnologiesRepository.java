package com.mentorondemand.dao;

import org.springframework.data.repository.CrudRepository;

import com.mentorondemand.model.Courses;

public interface TechnologiesRepository extends CrudRepository<Courses, Long>{
	
	

}
